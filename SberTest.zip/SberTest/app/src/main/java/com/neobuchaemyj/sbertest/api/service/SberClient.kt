package com.neobuchaemyj.sbertest.api.service

interface SberClient {


}